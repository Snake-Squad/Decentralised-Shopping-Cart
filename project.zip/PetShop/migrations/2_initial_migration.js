var Controller = artifacts.require("Controller");

module.exports = function(deployer) {
  deployer.deploy(Controller);
};